The Cybertruck 3D model used in this example was created by [PolyDucky](https://sketchfab.com/halpmehplzdaddy).

Source: [SketchFab](https://sketchfab.com/3d-models/tesla-cybertruck-1ab0c3f248fa47019c4311abce9731a0)

Licensed under [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/).